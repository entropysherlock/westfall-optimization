# AdaptivePair ATLAS-075 API deployment

This package contains the already-tested reference Python/FastAPI backend, not a production-secured customer-data service. It provides `/health`, `/v1/decision-support`, and `/v1/confidence`.

## Deploy with Render

1. Add the **contents of this ZIP** to a GitHub repository root (backend/ and render.yaml). Do not commit private customer data.
2. Connect the repository in Render and choose **New > Blueprint**. Review the free-plan limits and approve deployment.
3. In the completed Render service, visit `https://YOUR-SERVICE.onrender.com/health`; confirm JSON `status: ok`.
4. Open the AdaptivePair GitHub Pages homepage. Paste that exact HTTPS service origin in **ATLAS-075 API URL**, then click **Connect API**.
5. Test with synthetic sample data only. Render free services may sleep when idle.

The API is stateless and CORS-restricted to the GitHub Pages origin; **CORS is not authentication**. This research service currently has no authentication, rate limits, per-tenant isolation, or validated customer-data compliance. Do not expose private survey data to a public demo endpoint. For production, implement those safeguards and calibrate the bootstrap intervals under adaptive sampling.

## Local validation

```bash
pip install -r backend/requirements.txt
pip install pytest httpx
PYTHONPATH=backend python -m pytest -q backend/tests
uvicorn api:app --app-dir backend --host 127.0.0.1 --port 8000
```

Visit http://127.0.0.1:8000/app for the same-origin local interface or /docs for the API contract.
