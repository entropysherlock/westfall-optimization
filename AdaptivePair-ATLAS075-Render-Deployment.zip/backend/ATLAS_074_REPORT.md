# ATLAS-074 — Respondent-Level, Fatigue, and Vote-Efficiency Audit

**Date:** 2026-11-17  
**Status:** independent synthetic evaluation, NOT a customer-validated reduction in survey size.

## Research question

Can the ATLAS-073 adaptive pair selector improve OpinionX-compatible *raw win-rate differences* and uniformly opponent-standardized model gaps in a respondent-level survey model? Does it achieve equivalent accuracy using fewer pair presentations?

## Crucial correction to ATLAS-073

`atlas073.py` previously called the policy `variance`, but its benchmark selects the globally maximum posterior variance-reduction pair **without a coverage constraint**. In contrast, the real `selector073.py` endpoint allows only pairs at minimum exposure or one higher. Those are different algorithms. ATLAS-074 tests that **API-compatible minimum-plus-one guarded** variance policy, as well as balanced exposure and a strictly minimum-exposure-only guarded policy.

## Test design

- Eight product options, 28 possible pairs, 32/64/128/256 presentation budgets.
- Four scenarios: baseline; heterogeneous two-segment preferences; fatigue with skips and respondent dropout; cyclic/nontransitive preferences.
- Repeated respondents answer at most five questions, and cannot see the same pair twice (even if skipped). Synthetic outcomes are generated from respondent-specific latent utilities, pair-specific probabilities, and common pre-sampled random draws; no actual customer data are used.
- Fatigue/dropout scenario assigns elevated skips at later tasks and simulated early termination after the second response for some participants.
- Outcome: RMSE of **all option-level score differences**, against a *synthetic population's uniformly opponent-standardized choice probabilities*. Both raw overall win-rate gaps and independent Beta(1,1) posterior standardized-score gaps are evaluated.
- Initial correction run: 160 independent panels per scenario (7,680 policy-by-budget evaluations), seed 841927.
- Separate replication: 500 independent panels per scenario (24,000 policy-by-budget evaluations), seed 974201. All comparisons reuse each panel's underlying preferences and potential answer draws across policies.
- 24 software tests passed (`python -m pytest -q`).

## Replication results: 500 panels per scenario, 256 presentations

| Scenario | Balanced raw gap RMSE | Variance raw gap RMSE | Difference, adaptive minus balanced | 95% paired interval |
|---|---:|---:|---:|---|
| Baseline | see `atlas074_replication/summary.json` | see summary | -0.00127 | [-0.00392, +0.00137] |
| Two segments | see summary | see summary | -0.00066 | [-0.00329, +0.00198] |
| Fatigue/dropout | 0.08656 | 0.08272 | -0.00383 | [-0.00670, -0.00096] |
| Cyclic | **0.07244** | **0.06366** | **-0.00878 (~12.1% lower)** | **[-0.01094, -0.00661]** |

In cyclic preferences, the modeled standardized-gap RMSE also fell, from 0.06074 to 0.05801 (mean paired difference -0.00274; 95% interval [-0.00458, -0.00090]). The corresponding initial 160-panel replication also favored variance on cyclic raw gaps, but the other improvements were not consistently distinguished from noise. The strict guarded policy was less consistent, particularly under fatigue/dropout in the 160-panel study.

**These are exploratory confidence intervals.** They are normal-approximation paired intervals without multiple-comparison correction. Their reference is simulation-to-simulation variability, **not** customer-facing score uncertainty or coverage.

## Commercial efficiency finding — NOT PROVEN

At the tested presentation budgets 32,64,128,256, the variance-aware policy did **not** achieve an earlier-budget RMSE at or below the balanced policy's later-budget RMSE **for both raw and standardized gaps in any scenario** under the package's strict discrete-budget equivalence test. This does not prove no efficiency gain exists at untested intermediate budgets; it means the requested 20–30% fewer votes is **not established**.

A presentation is not necessarily an answered comparison. The study tracks attempted presentations, answered votes, skips, and early dropout separately.

## What to build next

1. Extend the simulator to continuous/intermediate vote budgets and pre-register a fixed non-inferiority tolerance on score gaps, measured with confidence intervals rather than a single mean.
2. Introduce respondent- and segment-aware allocation, and test more missingness mechanisms (e.g., preference-dependent skips), not just fatigue.
3. Calibrate customer-facing gap confidence intervals under adaptive assignment and unequal opponent exposures; compare to a simple balanced baseline.
4. Validate public benchmarks and, only with authorization, anonymized real survey data; do not infer access to OpinionX systems.
5. Preserve the existing OpinionX scoring system and allow the pair policy to fall back to balanced; a self-service audited integration is a separate engineering gate.

## Reproduce

```bash
cd adaptivepair-business
python -m pip install -r requirements.txt
python -m pip install pytest httpx
OPENBLAS_NUM_THREADS=1 python -m pytest -q
OPENBLAS_NUM_THREADS=1 python atlas074.py --reps 160 --seed 841927 --outdir atlas074_holdout
OPENBLAS_NUM_THREADS=1 python atlas074.py --reps 500 --seed 974201 --outdir atlas074_replication
```

All simulation data are synthetic. No production deployment, security audit, A/B test, or actual customer cost savings are claimed.
