# ATLAS-073: Variance-Aware Pair Selection — Independent Validation

**Date:** 2026-11-17. **Status:** promising synthetic result, **not a commercial or mathematical novelty claim**.

## Customer-centered objective

Reduce error in **score gaps** from pairwise survey outcomes without losing matchup coverage. Daniel Kyne said gaps, not just ordering, are important to OpinionX customers. The experiments target the uniformly opponent-standardized pairwise win probability for each option (a precisely defined *synthetic* estimand), not a psychological importance scale.

## Method

For each unordered pair (i,j), maintain wins `w_ij`, losses `l_ij`, and skips separately. Define `a=1+w_ij`, `b=1+l_ij`. Under independent Beta(1,1) pair priors, the posterior mean is `a/(a+b)` and variance is `ab/((a+b)^2 (a+b+1))`.

The **expected posterior variance reduction** from observing the next answered comparison is exactly

`ab / ((a+b)^2 (a+b+1)^2)`.

The experimental selector maximizes this quantity, subject to a safeguard that no eligible pair is shown more than one additional time above the **current minimum pair exposure**, as checked at selection time. This retains coverage and limits, but does not eliminate, exposure imbalance. Skips increase exposure without increasing answered comparisons.

The method requires only O(n²) candidate evaluation using maintained pair counts; the backward-compatible stateless adapter still parses vote history per call. Nothing requires a heavyweight model refit. This design belongs to established Bayesian experimental design, and the computations are **not claimed new**.

## Experiments

- Exploratory: **9,600 simulated surveys**, 200 synthetic seeds per scenario × budget × policy, 6 options, budgets 12,30,60; source `atlas073_results/`.
- **Held-out:** **48,000 simulated surveys**, 1,000 fresh seeds per scenario × budget × policy, same configuration; `atlas073_holdout/`.
- Larger-item stress: **2,560 simulated surveys**, 80 seeds × four scenarios × two budgets (90 and 180) × four policies, 10 options; `atlas073_stress/`.
- Scenarios: homogeneous, two-segment mixture, nontransitive/cyclic, and 17% random skips.
- Policies: balanced exposure; variance-aware exposure; guarded within-minimum-exposure ties; and uniform random.
- Comparison outcomes are generated from independently seeded, fixed per-pair outcome streams so shared encounters use the same random draws across policies. These are synthetic marginal preference probabilities; **not modeled as repeated individual respondent choices**.
- Primary outcome: root mean square error across **all pairwise differences** of option-level standardized win probabilities, computed against known synthetic ground truth. Results include *raw observed win-rate gaps* and *pairwise Beta-posterior standardized-score gaps*. All intervals are unadjusted paired 95% normal approximations.

## Main held-out results — six options, 60 comparisons

| Scenario | Balanced raw gap RMSE | Variance-aware raw gap RMSE | Relative difference | 95% interval for absolute difference (variance minus balanced) |
|---|---:|---:|---:|---|
| Cyclic | 0.12905 | 0.11115 | **13.87% lower** | [-0.01990, -0.01591] |
| Homogeneous | 0.14068 | 0.13721 | 2.46% lower | [-0.00524, -0.00169] |
| Skips | 0.15679 | 0.15137 | 3.46% lower | [-0.00743, -0.00341] |
| Two-segment mixture | 0.15221 | 0.15120 | 0.66% lower | [-0.00277, +0.00076] |

All four variance-aware settings at this budget maintained **100% pair coverage**. At 12–30 comparisons, the adaptive mechanism is often identical to balanced matching because of symmetry and the coverage safeguard, so **no blanket efficiency improvement is shown at low budgets**.

**Model-standardized-score error can move differently from raw-score error.** In the held-out two-segment scenario, model-gap RMSE slightly *increased* (0.12321 → 0.12411); the paired interval included zero. Do not assert that all gaps improve.

## More options, 180 comparisons

For 10 options and 80 synthetic replicates per policy per scenario, cyclic raw gap RMSE fell from **0.09973** to **0.08582**, a **13.95%** reduction (paired absolute improvement interval **0.00989–0.01793**). The sample is modest. See `atlas073_stress/summary.json`.

## Why this is not yet a business breakthrough

1. No real respondents, fatigue, correlated within-person answers, quota-based sampling, differential dropout, or assignment confounding.
2. Synthetic truth is the uniformly opponent-standardized marginal probability, not a calibrated psychological importance quantity.
3. A production system requires state persistence, distributed concurrency control, authentication, authorization, idempotency, latency tests, monitoring, and GDPR/privacy assessment.
4. No measurement that the same decision quality needs 20–30% fewer total responses; these results compare **equal budgets**.
5. No calibration of customer-facing uncertainty intervals and no independent external replication. The confidence intervals here are for average simulated policy differences, not for individual survey score gaps.
6. Adaptation may change the meaning of raw win rates. A blinded real-data A/B evaluation and explicit scoring compatibility plan would be mandatory.
7. Literature already documents active paired comparison design and adaptive-selection bias. This is an application-focused prototype, **not a novel theorem or algorithm**.

## Reproduction

```bash
cd adaptivepair-business
python -m pip install -r requirements.txt
python -m pip install pytest httpx
OPENBLAS_NUM_THREADS=1 python -m pytest -q
OPENBLAS_NUM_THREADS=1 python atlas073.py --reps 200 --seed 73026 --outdir atlas073_results
OPENBLAS_NUM_THREADS=1 python atlas073.py --reps 1000 --seed 991731 --outdir atlas073_holdout
OPENBLAS_NUM_THREADS=1 python stress073.py
uvicorn api:app --host 127.0.0.1 --port 8000
```

Experimental endpoint: `POST /v1/experimental/next-pair-073`, same payload structure as the v0.1 endpoint. Set `policy` to `variance` (or omit it; this endpoint maps the legacy `balanced_adaptive` default to `variance`). Original `/v1/next-pair` remains unchanged. `selector073.py` returns `experimental: true` and an explicit warning. Use the endpoint for local evaluation only.

## Decision

**GO for continued R&D and third-party validation; NO-GO for OpinionX production deployment or a general claim of survey savings.** A strong specific synthetic advantage replicated with fresh seeds and more options. Next gate: user-level response models and score-gap calibration, then a blinded pilot using consented anonymized data and pre-registered decision-quality endpoints.
