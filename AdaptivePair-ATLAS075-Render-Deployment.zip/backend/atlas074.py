"""ATLAS-074 respondent-level stress audit (synthetic). Python 3.10+, NumPy.

All policies are evaluated on common respondent panels and pre-sampled outcome
noise. This is an evaluation experiment, NOT an integration or customer claim.
"""
from __future__ import annotations
import argparse, csv, json, time, math
from pathlib import Path
import numpy as np

SCENARIOS=('baseline','segments','fatigue_dropout','cyclic')
POLICIES=('balanced','guarded','variance')

def logistic(x):
    return 1/(1+np.exp(-np.clip(x,-25,25)))

def trial(seed, scenario, n=8, budgets=(32,64,128,256)):
    rng=np.random.default_rng(seed)
    pairs=np.array([(a,b) for a in range(n) for b in range(a+1,n)],dtype=np.int32)
    ai,bi=pairs[:,0],pairs[:,1]; m=len(pairs); maxb=max(budgets)
    # A shared synthetic respondent panel. Each participant responds to <=5 questions.
    N=maxb+50
    common=rng.normal(0,0.95,n)
    secondary=rng.normal(0,1.05,n)
    seg=rng.integers(0,2,N)
    personal=rng.normal(0,.35,(N,n))
    utility=np.where(seg[:,None]==0,common,secondary) +personal if scenario=='segments' else common+personal
    probs=logistic(utility[:,ai]-utility[:,bi])
    if scenario=='cyclic':
        # Nontransitive link probabilities; zero mean overall does not mean zero cycle.
        cycle=np.array([1 if (a-b)%3==1 else -1 if (b-a)%3==1 else 0 for a,b in pairs])
        probs=logistic(.25*(utility[:,ai]-utility[:,bi])+1.9*cycle[None,:])
    # Synthetic population estimand, standardized to a uniform opponent.
    population=probs.mean(axis=0)
    target=np.zeros(n)
    for j,(a,b) in enumerate(pairs):target[a]+=population[j];target[b]+=1-population[j]
    target/=n-1
    # Potential outcome determined by respondent and pair (and occasion); common across policies.
    uniforms=rng.random((N,5,m))
    skip_random=rng.random((N,5,m))
    dropout_random=rng.random(N)
    order_rng=rng.random((maxb,m))
    outputs=[]
    for policy in POLICIES:
        counts=np.zeros(m,dtype=np.int32);yes=np.zeros(m,dtype=np.int32);no=np.zeros(m,dtype=np.int32)
        respondent=0;ordinal=0;shown=0;dropped=0;skipped=0;answers=0;respondent_seen=set()
        for t in range(1,maxb+1):
            if policy=='balanced': scores=-counts.astype(float)
            else:
                alpha=yes+1;beta=no+1;total=alpha+beta
                gain=(alpha*beta)/(total*total*(total+1)**2)
                if policy=='guarded':scores=np.where(counts==counts.min(),gain,-1.)
                else:scores=np.where(counts<=counts.min()+1,gain,-1.)
            if respondent_seen:
                scores[list(respondent_seen)]=-np.inf
            i=int(np.argmax(scores+order_rng[t-1]*1e-12))
            respondent_seen.add(i)
            counts[i]+=1;shown+=1
            if scenario=='fatigue_dropout':
                # Differential attrition and skipping after repeated tasks.
                pskip=.035+.05*ordinal+.06*float(abs(probs[respondent,i]-.5)<.15)
            else:pskip=.025
            if skip_random[respondent,ordinal,i]<pskip:skipped+=1
            elif uniforms[respondent,ordinal,i]<probs[respondent,i]:yes[i]+=1;answers+=1
            else:no[i]+=1;answers+=1
            ordinal+=1
            if ordinal==5 or (scenario=='fatigue_dropout' and ordinal>=2 and dropout_random[respondent]<.38):
                if ordinal<5:dropped+=1
                ordinal=0;respondent+=1;respondent_seen.clear()
            if t in budgets:
                # Raw win rate is intentionally reported as the customer's currently
                # familiar statistic, but this has nonuniform-opponent confounding.
                w=np.zeros(n);observed=np.zeros(n)
                model=np.zeros(n)
                pp=(yes+1)/(yes+no+2)
                for j,(a,b) in enumerate(pairs):
                    w[a]+=yes[j];w[b]+=no[j]
                    observed[a]+=yes[j]+no[j];observed[b]+=yes[j]+no[j]
                    model[a]+=pp[j];model[b]+=1-pp[j]
                model/=n-1
                raw=np.divide(w,observed,out=np.full(n,np.nan),where=observed>0)
                def rmse(v):
                    mask=np.isfinite(v)
                    if mask.sum()<2:return float('nan')
                    z=v[mask]-target[mask]
                    return float(np.sqrt((len(z)*np.dot(z,z)-z.sum()**2)/(len(z)*(len(z)-1)/2)))
                outputs.append(dict(seed=seed,scenario=scenario,policy=policy,budget=t,raw_gap_rmse=rmse(raw),model_gap_rmse=rmse(model),coverage=float(np.mean(counts>0)),answered=answers,skipped=skipped,dropped=dropped,exposure_spread=int(counts.max()-counts.min())))
    return outputs

def summarise(rows,budgets):
    data=[]; paired=[]
    for scenario in SCENARIOS:
      for budget in budgets:
        rr=[r for r in rows if r['scenario']==scenario and r['budget']==budget]
        base={r['seed']:r for r in rr if r['policy']=='balanced'}
        for policy in POLICIES:
          v=[r for r in rr if r['policy']==policy]
          entry={'scenario':scenario,'budget':budget,'policy':policy,'reps':len(v)}
          for metric in ('raw_gap_rmse','model_gap_rmse','coverage','answered','skipped','dropped','exposure_spread'):
            vals=np.array([r[metric] for r in v],dtype=float);entry[metric]=round(float(np.nanmean(vals)),6)
          data.append(entry)
          if policy!='balanced':
            d={'scenario':scenario,'budget':budget,'policy':policy}
            for metric in ('raw_gap_rmse','model_gap_rmse'):
              diffs=np.array([r[metric]-base[r['seed']][metric] for r in v]); diffs=diffs[np.isfinite(diffs)]
              avg=float(np.mean(diffs));se=float(np.std(diffs,ddof=1)/np.sqrt(len(diffs)))
              d[metric+'_difference']=round(avg,6);d[metric+'_ci95']=[round(avg-1.96*se,6),round(avg+1.96*se,6)]
            paired.append(d)
    # Only count a savings claim when an adaptive policy at an earlier budget
    # beats balanced at a later budget across BOTH gap metrics, per scenario.
    savings=[]
    for scenario in SCENARIOS:
      for policy in ('guarded','variance'):
        for big in budgets[1:]:
          baseline=next(x for x in data if x['scenario']==scenario and x['policy']=='balanced' and x['budget']==big)
          candidates=[x for x in data if x['scenario']==scenario and x['policy']==policy and x['budget']<big and x['raw_gap_rmse']<=baseline['raw_gap_rmse'] and x['model_gap_rmse']<=baseline['model_gap_rmse']]
          if candidates:
            c=min(candidates,key=lambda x:x['budget']);savings.append({'scenario':scenario,'policy':policy,'baseline_budget':big,'candidate_budget':c['budget'],'nominal_savings_fraction':round(1-c['budget']/big,4),'warning':'Uncertainty of cross-budget equivalence not established'})
    return data,paired,savings

def run(reps,seed,budgets,n,outdir):
    start=time.monotonic();rows=[]
    for si,scenario in enumerate(SCENARIOS):
      for i in range(reps):rows.extend(trial(seed+si*100000+i,scenario,n,budgets))
    data,paired,savings=summarise(rows,budgets)
    path=Path(outdir);path.mkdir(parents=True,exist_ok=True)
    with (path/'trials.csv').open('w',newline='') as f:
      writer=csv.DictWriter(f,fieldnames=rows[0].keys());writer.writeheader();writer.writerows(rows)
    result={'configuration':{'reps':reps,'seed':seed,'n':n,'budgets':budgets,'scenarios':SCENARIOS,'policies':POLICIES,'trial_rows':len(rows),'runtime_seconds':round(time.monotonic()-start,2)},'summary':data,'paired':paired,'nominal_budget_comparisons':savings,'limitations':['Synthetic respondent panel, no customer data','Respondent probabilities fixed during survey, fatigue only affects skip/dropout not preference strength','Uniform-opponent standardized probability is an estimand, not psychological importance','Reported paired 95% normal intervals are not multiplicity-adjusted','Dropout model and respondent allocation are hypothetical','Pair repetitions are prohibited within a respondent; skipped pairs are also excluded for that respondent','The selector in atlas073.py benchmark is unconstrained whereas the selector073.py API variance policy enforces a minimum+1 exposure guard; this benchmark tests the guarded API behavior','Apparent cross-budget equivalence needs uncertainty assessment and dedicated prospective pre-registration']}
    (path/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'rows':len(rows),'runtime':result['configuration']['runtime_seconds'],'paired_at_max_budget':[x for x in paired if x['budget']==max(budgets)],'nominal_savings':savings},indent=2))
    return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--reps',type=int,default=100);ap.add_argument('--seed',type=int,default=74026);ap.add_argument('--items',type=int,default=8);ap.add_argument('--budgets',nargs='+',type=int,default=[32,64,128,256]);ap.add_argument('--outdir',default='atlas074_results');a=ap.parse_args()
    run(a.reps,a.seed,a.budgets,a.items,a.outdir)
