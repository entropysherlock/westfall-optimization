"""Survey-design-aware exploratory uncertainty audit, ATLAS-075.

Nonparametric respondent-cluster bootstrap. Not a formal significance test or
calibrated interval under arbitrary adaptive assignment/nonresponse.
"""
from __future__ import annotations
from collections import defaultdict
import math
import numpy as np
from engine import parse, _fit, _check_id

MAX_CONF_ITEMS = 30
MAX_CONF_VOTES = 5000
MAX_BOOTSTRAPS = 400

def _score(ids, votes, ix, fit=True):
    n=len(ids)
    wins=np.zeros((n,n),dtype=np.int64)
    effective=np.zeros((n,n),dtype=np.int64)
    skips=np.zeros((n,n),dtype=np.int64)
    for v in votes:
        a,b=ix[v['a']],ix[v['b']]
        if v.get('winner') is None:
            skips[a,b]+=1;skips[b,a]+=1
        else:
            effective[a,b]+=1;effective[b,a]+=1
            w=ix[v['winner']]; loser=b if w==a else a
            wins[w,loser]+=1
    denominators=effective.sum(axis=1)
    raw=np.divide(wins.sum(axis=1),denominators,out=np.full(n,np.nan),where=denominators>0)*100
    if fit:
        theta,p,_=_fit(wins,effective+skips,skips)
        standardized=(p.sum(axis=1)-0.5)*100/(n-1)
    else: standardized=np.full(n,np.nan)
    return raw, standardized, denominators

def _interval(values):
    a=np.asarray(values,dtype=float)
    a=a[np.isfinite(a)]
    if len(a)==0:return None
    return [round(float(x),4) for x in np.quantile(a,[.025,.975])]

def confidence(payload:dict)->dict:
    ids, counts, wins, skips, seen=parse(payload)
    votes=payload.get('votes',[])
    if len(ids)>MAX_CONF_ITEMS or len(votes)>MAX_CONF_VOTES:
        raise ValueError(f'confidence endpoint supports at most {MAX_CONF_ITEMS} items and {MAX_CONF_VOTES} votes')
    replicas=payload.get('replicates',200)
    if type(replicas) is not int or not 40<=replicas<=MAX_BOOTSTRAPS:
        raise ValueError(f'replicates must be an integer between 40 and {MAX_BOOTSTRAPS}')
    seed=payload.get('seed',0)
    if type(seed) is not int or abs(seed)>2**31-1:raise ValueError('seed must be a 32-bit integer')
    pairs=payload.get('contrasts',[])
    if not isinstance(pairs,list) or len(pairs)>30:raise ValueError('contrasts must be an array of at most 30 pairs')
    for i,pair in enumerate(pairs):
        if not isinstance(pair,dict) or set(pair)!={'a','b'} or pair['a'] not in ids or pair['b'] not in ids or pair['a']==pair['b']:
            raise ValueError(f'contrasts[{i}] requires distinct valid a and b IDs')
    ix={item:i for i,item in enumerate(ids)}
    # Each anonymous response without respondent ID is an independent cluster.
    clusters=defaultdict(list)
    explicitly_identified=set()
    for i,v in enumerate(votes):
        rid=v.get('respondent_id')
        if rid is None:key=('anonymous_row',i)
        else:
            key=('respondent',rid);explicitly_identified.add(rid)
        clusters[key].append(v)
    raw, model, denom=_score(ids,votes,ix)
    # Only report intervals when enough independently sampled clusters exist.
    enough=len(clusters)>=10 and sum(v.get('winner') is not None for v in votes)>=10
    intervals_raw=[None]*len(ids)
    intervals_model=[None]*len(ids)
    draws_raw=np.full((0,len(ids)),np.nan)
    draws_model=np.full((0,len(ids)),np.nan)
    if enough:
        groups=list(clusters.values())
        rng=np.random.default_rng(seed)
        draws_raw=np.empty((replicas,len(ids)))
        draws_model=np.empty((replicas,len(ids)))
        for b in range(replicas):
            selection=rng.integers(0,len(groups),size=len(groups))
            sampled=[v for k in selection for v in groups[int(k)]]
            rv,mv,_=_score(ids,sampled,ix)
            draws_raw[b]=rv
            draws_model[b]=mv
        intervals_raw=[_interval(draws_raw[:,i]) for i in range(len(ids))]
        intervals_model=[_interval(draws_model[:,i]) for i in range(len(ids))]
    rows=[]
    for i,item in enumerate(ids):
        rows.append({'item':item,'answered':int(denom[i]),
          'observed_win_rate':round(float(raw[i]),4) if np.isfinite(raw[i]) else None,
          'observed_win_rate_interval':intervals_raw[i],
          'model_standardized_score':round(float(model[i]),4),
          'model_standardized_interval':intervals_model[i]})
    contrasts=[]
    for pair in pairs:
        a,b=ix[pair['a']],ix[pair['b']]
        raw_gap=raw[a]-raw[b]
        mod_gap=model[a]-model[b]
        # A and B are fixed before examining bootstrap replicates; percentile
        # intervals do not adjust for post hoc pair selection/multiple contrasts.
        contrasts.append({'a':pair['a'],'b':pair['b'],
          'observed_win_rate_gap':round(float(raw_gap),4) if np.isfinite(raw_gap) else None,
          'observed_win_rate_gap_interval':_interval(draws_raw[:,a]-draws_raw[:,b]),
          'model_standardized_gap':round(float(mod_gap),4),
          'model_standardized_gap_interval':_interval(draws_model[:,a]-draws_model[:,b])})
    answered=int(sum(v.get('winner') is not None for v in votes))
    total=int(len(votes))
    warnings=[]
    if not enough:warnings.append('At least 10 independent response clusters and 10 answers are needed for bootstrap intervals; intervals omitted.')
    if any(v.get('respondent_id') is None for v in votes):warnings.append('Responses without respondent_id are treated as independent clusters; if multiple responses came from the same person, intervals may be too narrow.')
    if len(explicitly_identified)<10 and len(explicitly_identified)>0:warnings.append('Few uniquely identified respondents; do not interpret bootstrap ranges as definitive significance tests.')
    if np.any(denom==0):warnings.append('Some options have no answered comparisons, so their observed win rates and associated gaps are undefined.')
    if np.any((counts-skips).sum(axis=1)==0):warnings.append('The standardized model estimates for unobserved options are driven by ridge regularization.')
    warnings.append('Intervals are exploratory respondent-cluster bootstrap percentile ranges, conditional on observed survey design; they do not correct adaptive selection, nonrandom missingness, self-selection, or multiple testing.')
    warnings.append('Model-standardized scores depend on Bradley–Terry assumptions; neither score measures cardinal psychological importance without additional assumptions.')
    return {'status':'ok','summary':{'items':len(ids),'responses':total,'answered':answered,'respondent_clusters':len(clusters),'identified_respondents':len(explicitly_identified),'replicates':replicas if enough else 0,'interval_level':0.95,'intervals_available':enough},
            'scores':rows,'contrasts':contrasts,'warnings':warnings,
            'methodology':{'resampling_unit':'respondent_id; each missing respondent_id is an independent row',
              'method':'percentile cluster bootstrap with seeded replacement of respondent clusters',
              'observed_score':'100 * wins / answered comparisons; skips excluded',
              'model_score':'ridge-regularized Bradley–Terry probabilities averaged across every opponent',
              'interpretation':'exploratory intervals, not design-calibrated confidence guarantees'}}
