"""ATLAS-073 score-gap experimental selector. No claim of production readiness.

Sufficient statistics are computable incrementally; the stateless adapter parses
vote history each request for backwards compatibility. No BT fitting is needed.
"""
from __future__ import annotations
import hashlib
import numpy as np
from engine import parse,_check_id

def next_pair_073(payload:dict)->dict:
    ids,counts,wins,skips,seen=parse(payload)
    policy=payload.get('policy','variance')
    if policy not in ('variance','balanced','guarded'):
        raise ValueError('policy must be variance, balanced, or guarded')
    rid=payload.get('respondent_id')
    if rid is not None:_check_id(rid,'respondent_id')
    excluded=payload.get('exclude_items',[])
    if not isinstance(excluded,list) or any(x not in ids for x in excluded):
        raise ValueError('exclude_items must be recognized IDs')
    excluded=set(excluded)
    seed=payload.get('seed',0)
    if type(seed) is not int or abs(seed)>2**31-1:raise ValueError('seed must be a 32-bit integer')
    pairs=[]
    for a in range(len(ids)):
        for b in range(a+1,len(ids)):
            if ids[a] in excluded or ids[b] in excluded:continue
            if rid is not None and (rid,a,b) in seen:continue
            pairs.append((a,b))
    if not pairs:return {'status':'exhausted','pair':None,'eligible_pairs':0}
    minimum=min(int(counts[a,b]) for a,b in pairs)
    def priority(a,b):
        played=int(counts[a,b]);effective=played-int(skips[a,b]);wa=int(wins[a,b]);wb=int(wins[b,a])
        alpha=wa+1;beta=wb+1;total=alpha+beta
        expected_gain=(alpha*beta)/(total*total*(total+1)**2)
        if policy=='balanced':score=-played
        elif policy=='guarded':score=expected_gain if played==minimum else -1
        else:
            # Keep complete coverage and an exposure spread at most 2 among
            # eligible pairs, even with heterogeneous/noisy responses.
            score=expected_gain if played<=minimum+1 else -1
        h=hashlib.sha256(f'{seed}|{ids[a]}|{ids[b]}'.encode()).digest()
        tie=int.from_bytes(h[:8],'big')/2**64
        return(score,tie)
    a,b=max(pairs,key=lambda v:priority(*v))
    played=int(counts[a,b]);wa=int(wins[a,b]);wb=int(wins[b,a]);total=wa+wb+2
    return {'status':'ok','pair':{'a':ids[a],'b':ids[b]},'selection':{
      'policy':policy,'comparisons':played,'answered':wa+wb,
      'predicted_win_probability_a':round((wa+1)/total,6),
      'expected_posterior_variance_reduction':round((wa+1)*(wb+1)/(total*total*(total+1)**2),10),
      'eligible_pairs':len(pairs),'eligible_min_exposure':minimum,
      'experimental':True,
      'warning':'Adaptive matching may distort raw win-rate score gaps. Validate under actual respondent assignment and missingness before use.'}}
