# ATLAS-072 — Customer-first matchup validation

**Date:** 2026-11-17  
**Status:** completed exploratory simulation, **NOT validated for deployment to OpinionX customers**.  
**Scope:** evaluation of unchanged AdaptivePair v0.1 selector and score diagnostics.

## Experiment

- **960 synthetic surveys**: 4 scenarios × 2 comparison budgets × 30 independently generated surveys × 4 policies.
- 6 options per survey; budgets 12 and 30 comparisons. Total **20,160 simulated matchup presentations**.
- Scenarios: homogeneous Bradley–Terry preferences; heterogeneous 50/50 mixture of two Bradley–Terry segments; nontransitive cyclic preferences; homogeneous preferences with 17% skip chance.
- Policies: deterministic-seeded pseudo-random matching, minimum-exposure balanced matching, balanced matching with information-gain tie-breaker, unrestricted information-gain heuristic.
- Primary endpoint: root mean square error (RMSE) in **pairwise differences of standardized option scores** relative to known synthetic choice probabilities. Lower is better.
- Report **both** model-standardized score gaps and raw win-rate gaps, since preserving raw score meaning is a critical adoption constraint.
- Policies share survey-specific ground truth and fixed response random draws per unordered pair and encounter count; outcomes across different queried pairs cannot be made identical.
- Source: `benchmark_072.py`, output: `atlas072_results/summary.json` and `trials.csv`.

## Selected results: 12 comparisons per survey

| Scenario | Balanced model-gap RMSE | Balanced-adaptive model-gap RMSE | Balanced raw-gap RMSE | Balanced-adaptive raw-gap RMSE |
|---|---:|---:|---:|---:|
| Homogeneous | 0.2107 | 0.2038 | 0.2894 | 0.3068 |
| Two respondent segments | 0.2182 | 0.2165 | 0.3678 | 0.3603 |
| Cyclic preferences | 0.1636 | **0.2134** | 0.3103 | **0.4100** |
| Skips (17%) | 0.2334 | 0.2313 | 0.3754 | 0.3887 |

At 30 comparisons, balanced and balanced-adaptive were identical under these settings for all four scenarios. The unrestricted information policy sometimes improves model-based estimates but can reduce coverage and produce less reliable raw gaps.

## Conclusion and decision

**NO-GO for claiming survey-efficiency or improved importance-gap performance to customers.**

The existing balanced-adaptive selector is a *tie-breaking variant of balanced matching*, rather than a mature adaptive experimental design. It does not provide consistent improvement and can cause larger gap errors under model misspecification. In particular, even when model-standardized scores slightly improve, raw win-rate gaps can worsen.

**Next development gate:** introduce a candidate pair policy optimized for score-gap accuracy and uncertainty, retain a balanced fallback, then rerun a pre-registered paired experiment covering segments, skips, respondent fatigue, nontransitivity, and fixed respondent budgets. Do not add a customer-facing claim until results replicate on held-out simulations and, where permitted, real anonymized data.

## Accuracy and scope caveats

- All data are synthetic. No private OpinionX data or actual customer outcomes were used.
- The latent Bradley–Terry fit is a research diagnostic and does not directly identify perceived psychological importance.
- These are sample means from 30 replicates per setting, not confirmed commercially important effects. Paired difference 95% normal-approximation intervals are in `summary.json`, without multiple-testing correction.
- Real respondent heterogeneity, survey targeting, dropouts, and measurement bias are not fully represented. In particular, the experiment simulates skips but **not** respondent fatigue or real dropout processes.
- 960 surveys does **not** meet the initially proposed 10,000-survey validation target. A larger run was attempted but exceeded computational limits due to per-vote statistical refitting. This performance issue itself is an engineering priority.
- The current API is **not** suitable for direct commercial deployment without persistence, authentication, load testing, and security review.

## Reproduce

```bash
python -m pip install -r requirements.txt
python -m pip install pytest httpx
python -m pytest -q
OPENBLAS_NUM_THREADS=1 python benchmark_072.py --reps 30 --outdir atlas072_results
```

Set `--reps 300` for a much larger experiment, but be aware that the unchanged v0.1 backend is computationally expensive. Re-run on an appropriately sized machine and allow more runtime.
