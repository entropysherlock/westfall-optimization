"""Reproducible sanity check, not an assurance of survey-design calibration."""
import json
import numpy as np
from confidence import confidence

def run(seed=750,panels=120,respondents=60,replicates=80):
    rng=np.random.default_rng(seed)
    covered=0
    widths=[]
    for panel in range(panels):
        votes=[]
        for i in range(respondents):
            a_wins=bool(rng.random()<.6)
            votes.append({'a':'A','b':'B','winner':'A' if a_wins else 'B','respondent_id':f'p{i}'})
        result=confidence({'items':['A','B'],'votes':votes,'contrasts':[{'a':'A','b':'B'}],
                           'seed':seed+panel,'replicates':replicates})
        ci=result['contrasts'][0]['observed_win_rate_gap_interval']
        covered+=int(ci[0]<=20<=ci[1]);widths.append(ci[1]-ci[0])
    return {'design':'independent respondents, one A/B vote per respondent, P(A wins)=0.6',
            'panels':panels,'respondents_per_panel':respondents,'bootstrap_replicates':replicates,
            'expected_true_raw_gap_points':20,'empirical_95pct_interval_coverage':covered/panels,
            'mean_interval_width_points':round(float(np.mean(widths)),3),
            'warning':'Coverage here is specific to independent Bernoulli sampling; it does not validate intervals under adaptive scheduling, cluster selection, quota weighting, selection bias, or dropout.'}

if __name__=='__main__':print(json.dumps(run(),indent=2))
