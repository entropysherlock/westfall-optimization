# AdaptivePair — integration-oriented reference service (v0.1)

**Not affiliated with OpinionX. No proprietary integrations or production readiness claimed.**

This package answers the actual product question: *given an existing survey's options and its previous comparisons, which two items should a particular participant see next?* It is designed for a controlled opt-in evaluation of different selection strategies, and **does not replace OpinionX's observed win-rate scoring**.

## Run

```bash
python -m pip install -r requirements.txt
python -m pip install pytest httpx
python -m pytest -q
uvicorn api:app --host 127.0.0.1 --port 8000
```

At `http://127.0.0.1:8000/docs`, inspect the interactive API schema.

### Request

```bash
curl -X POST http://127.0.0.1:8000/v1/next-pair \
 -H 'Content-Type: application/json' \
 --data-binary @examples/request.json
```

Returns the next `a,b` IDs, selection rationale, current exposure, and diagnostic information. `GET /health` returns readiness. `POST /v1/diagnostics` takes `{ "items": [...], "votes": [...] }` and returns observed win rates, comparison coverage, skip counts, connectivity warnings and **explicitly exploratory** model-standardized scores.

## Design rationale

- **Default `balanced_adaptive`:** always select among pairs with the fewest historical presentations, then use an information-based tie-breaker. This targets better information *without abandoning pair exposure balance*. Balance is not a guarantee of unbiased scores when respondents differ, skip, or leave surveys.
- `balanced`: minimum-exposure pairs with deterministic tie-breaker.
- `information`: unconstrained BT information-gain heuristic for research. **Not recommended with raw win-rate score reporting unless independently validated.**
- `random`: deterministic hash-based pair choice for testing. Not cryptographic or unbiased-by-design sampling.
- Respondent ID prevents a participant seeing a pair twice, if supplied. IDs must be **anonymous**; do not send email, name, or IP address.
- `winner: null` = skipped comparison, counted for exposure but excluded from win-rate denominators.
- Fully stateless; caller provides previous votes. Persistence remains in the caller's system.

## Integration contract

Inputs: stable option IDs, vote records (`a`, `b`, `winner`, optional anonymous `respondent_id`), current respondent ID, optional excluded options, selected policy, stable seed. Output: next pair or exhausted. No OpinionX internal schemas or database permissions needed.

At significant scale, this proof of concept will require incremental state, indexed exposure tracking, efficient model updates, throughput profiling, and versioned interfaces; sending the whole vote history to every HTTP request is intentionally **not** proposed as a production integration for thousands of respondents.

## Safety & limits

- **Prototype, not deploy-ready.** The adapter binds to localhost in the documented command; production needs authentication, TLS, observability, request limits, rate limits, audit logs, and availability tests.
- `items` limited to 250 and `votes` to 100,000; dense matrix covariance makes large surveys computationally expensive; benchmark before deployment.
- Model-standardized scores are ridge Bradley–Terry predictions averaged uniformly over opponents. They are *not* native OpinionX win-rate scores, nor calibrated confidence intervals, and don't identify absolute psychological importance.
- Existing scores should remain unchanged unless the customer explicitly opts into new estimates.
- Pair coverage and observed win rates **must** be compared with current production selection in a properly randomized, consented customer experiment before promising fewer votes.
- No access to real OpinionX customer data, no agreement from Daniel to integrate, and no claims of customer lift.

## Immediate next engineering milestones

1. Add deterministic candidate sampling and incremental stats for 500–7,000 item scales; current dense matrices don't support that efficiently.
2. Offline replay through real anonymized survey exports (with permission), comparing coverage, estimated gap sensitivity, skip handling and segment behavior.
3. A shadow-mode A/B experiment that does not affect customer-facing scores until pre-registered accuracy, latency and fairness criteria pass.
4. Production adapter written against confirmed API/schema supplied by the host product; no guessed endpoints.

## Underlying references

- OpinionX Pair Rank documentation: https://knowledge.opinionx.co/en/articles/5866366-pair-rank
- OpinionX April 2023 scoring explanation: https://www.opinionx.co/changelog/ranking-formula-update-apr2023

## No-integration CSV audit

If Daniel can share an *anonymized* export with explicit authorization, translate the export to `a,b,winner,respondent_id` (blank winner = skip) and run:

```bash
python audit.py examples/sample_votes.csv --next-pair --out audit_report.json
python benchmark.py --reps 30 --items 7 --votes 35 --seed 11 --out benchmark_report.json
```

Reports contain raw win rates, item-by-item exposure, score-gap diagnostics and warnings; the benchmark contrasts policies under synthetic, explicitly simplified assumptions. **Do not treat benchmark means as customer impact claims.**

## ATLAS-075: Statistical Confidence Engine (research)

`POST /v1/confidence` accepts `items`, `votes`, optional `contrasts`, `replicates` (40–400) and `seed`.
`POST /v1/decision-support` accepts those fields plus `respondent_id`, `policy` (`variance`, `balanced`, `guarded`) and `exclude_items`. It returns both an ATLAS-073 recommended pair and an exploratory respondent-cluster bootstrap audit.

See [ATLAS_075_REPORT.md](ATLAS_075_REPORT.md) for estimands, example JSON, exact limits, and major inferential limitations. **The intervals are not currently calibrated to adaptive matching, and must not be used as definitive statistical significance claims.**
