# ATLAS-075 — Statistical Confidence Engine

**Status:** Working reference implementation; NOT an OpinionX integration or commercial-ready inference service.

## Scope

Added `confidence.py` with an explicit `POST /v1/confidence` endpoint and a combined `POST /v1/decision-support` endpoint. The latter calls the existing ATLAS-073 variance selector, then produces uncertainty diagnostics from the same survey history. Previous endpoints remain intact.

## Estimands and intervals

- **Observed win rate**: `100 × wins / answered comparisons` per item; skips excluded.
- **Observed score gap**: observed win-rate A minus observed win-rate B (percentage points), which is sensitive to opponent selection.
- **Model-standardized score**: uniform average of a ridge-regularized Bradley–Terry probability of beating each other item, scaled 0–100. This is a model-dependent diagnostic, **not** an objectively identified importance magnitude.
- **Model-standardized gap**: difference in the above standardized scores.
- **Intervals**: seeded *percentile bootstrap* over respondents. All votes from the same `respondent_id` are resampled together. Each response lacking an ID is treated as an independent cluster and triggers a warning. Returns 2.5th and 97.5th bootstrap percentiles for scores and **pre-specified** pair contrasts.
- No interval is reported when fewer than 10 independent response clusters or fewer than 10 answered comparisons exist. Intervals remain exploratory even above those thresholds.

## Guardrails

- Inputs reuse `engine.parse`: validates item IDs and votes, rejects repeated pair for same respondent.
- Confidence endpoint limits: 30 items, 5,000 vote records, 40–400 bootstrap replicates, at most 30 contrasts.
- No significance or posterior-probability assertion; no automatic winner declarations.
- Does **not** correct self-selection, informative dropout, adaptivity, design-based unequal selection probabilities, respondent quota weighting, post hoc multiple testing, or confounding. Bootstrap conditional on observed design may undercover in those settings.
- Requires further work on exposure-aware estimands and calibrated design-based intervals before deployment on production customer decisions.

## Example

Run in the project directory:

```bash
python -m pip install -r requirements.txt
python -m pip install pytest httpx
python -m pytest -q tests
uvicorn api:app --host 127.0.0.1 --port 8000
```

Send request to `POST http://127.0.0.1:8000/v1/decision-support`:

```json
{
  "items": ["Feature A", "Feature B", "Feature C"],
  "respondent_id": "new-respondent",
  "policy": "variance",
  "replicates": 200,
  "seed": 17,
  "contrasts": [{"a":"Feature A","b":"Feature B"}],
  "votes": [
    {"a":"Feature A","b":"Feature B","winner":"Feature A","respondent_id":"r1"},
    {"a":"Feature A","b":"Feature C","winner":"Feature C","respondent_id":"r1"},
    {"a":"Feature A","b":"Feature B","winner":"Feature B","respondent_id":"r2"}
  ]
}
```

`next_matchup` returns the recommended next eligible pair, while `confidence_audit` returns respondent-cluster counts, score intervals, contrast intervals, and warnings. Small example deliberately has **insufficient independent clusters**; intervals return `null`.

## Reproducibility

- Regression suite: **32/32 passing** as executed in this environment.
- `python calibration_075.py` ran 120 independent two-item Bernoulli survey panels (60 independent respondents per panel, true P(A wins) = 0.60, 80 bootstrap replicates). Observed 95% interval coverage of the true raw gap was **0.95**; average width **46.135 percentage points**. This is a *sanity check of one simple independent-data case*, not a validation of adaptive survey inference.
- Full calibration output: `ATLAS_075_CALIBRATION.json`.

## Recommended next independent verification

1. Stress designs with informative respondent dropout and nonuniform pair allocation; quantify coverage failure.
2. Add known/recorded matchup assignment propensities and validate inverse-probability or doubly robust gap estimators (including variance and positivity diagnostics).
3. Add stratified cluster-resampling for preregistered segments and multiplicity controls for displayed comparisons.
4. Validate on consented, anonymized real survey records before claims of better customer decisions.

**The code is an independent research demonstration. Not sponsored, certified, or adopted by OpinionX.**
