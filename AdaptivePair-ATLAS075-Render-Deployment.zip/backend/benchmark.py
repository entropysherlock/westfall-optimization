"""Pre-deployment randomized simulation benchmark, with paired ground truth.

Compares balanced and balanced_adaptive policies at a fixed budget using a
pre-generated independent response randomization source for each replicate.
This is an exploratory model check, not a field-effect estimate.
"""
import argparse,json,math
from pathlib import Path
import numpy as np
from engine import next_pair,diagnose

def logistic(x):return 1/(1+math.exp(-max(-30,min(30,x))))

def run(seed=11,reps=30,n=7,budget=35):
    rng=np.random.default_rng(seed)
    records=[]
    for rep in range(reps):
        truth=rng.normal(0,1,n)
        items=[f'item-{j}' for j in range(n)]
        true_margins={(a,b):logistic(float(truth[a]-truth[b])) for a in range(n) for b in range(a+1,n)}
        for policy in ('balanced','balanced_adaptive','information'):
            votes=[]
            # Note: shared truth across policies; independently sampled outcomes.
            prng=np.random.default_rng(seed*100_000+rep*17+['balanced','balanced_adaptive','information'].index(policy))
            for step in range(budget):
                suggested=next_pair({'items':items,'votes':votes,'policy':policy,'seed':int(prng.integers(2**31))})
                if suggested['status']!='ok':break
                a,b=map(lambda x:int(x.split('-')[1]),suggested['pair'].values())
                prob=logistic(float(truth[a]-truth[b]))
                votes.append({'a':items[a],'b':items[b],'winner':items[a] if prng.random()<prob else items[b]})
            d=diagnose({'items':items,'votes':votes})
            score={int(x['item'].split('-')[1]):x['model_standardized_score']/100 for x in d['scores']}
            # Compare estimated probability differences using standardized score
            # vs average true win probability against all opposing items.
            actual={i:sum(logistic(float(truth[i]-truth[j])) for j in range(n) if i!=j)/(n-1) for i in range(n)}
            rmse=math.sqrt(sum((score[i]-actual[i])**2 for i in range(n))/n)
            records.append({'rep':rep,'policy':policy,'score_rmse':rmse,
                            'pair_coverage':d['summary']['pair_coverage_fraction'],
                            'exposure_range':d['summary']['max_pair_exposure']-d['summary']['min_pair_exposure']})
    agg={}
    for policy in ('balanced','balanced_adaptive','information'):
        r=[x for x in records if x['policy']==policy]
        agg[policy]={k:round(float(np.mean([x[k] for x in r])),5) for k in ('score_rmse','pair_coverage','exposure_range')}
        agg[policy]['score_rmse_se']=round(float(np.std([x['score_rmse'] for x in r],ddof=1)/np.sqrt(reps)),5) if reps>1 else None
    return {'settings':{'seed':seed,'replicates':reps,'items':n,'votes_per_survey':budget,
                        'metric':'Model-standardized score RMSE against true homogeneous BT marginal probabilities'},
            'aggregate':agg,'trials':records,
            'limitations':['Synthetic homogeneous Bradley-Terry responders only','No respondent dropout, skips, segmentation or preference cycles','Policy outcomes not paired by response random draws','Model-based metric favors correctly specified BT models; no customer lift claimed']}

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--reps',type=int,default=30);p.add_argument('--items',type=int,default=7)
    p.add_argument('--votes',type=int,default=35);p.add_argument('--seed',type=int,default=11)
    p.add_argument('--out',default='benchmark_report.json')
    a=p.parse_args()
    if a.reps<2 or not 2<=a.items<=30 or a.votes<1: p.error('Use >=2 reps, 2-30 items, >=1 vote')
    report=run(a.seed,a.reps,a.items,a.votes)
    Path(a.out).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report['aggregate'],indent=2))

if __name__=='__main__':main()
