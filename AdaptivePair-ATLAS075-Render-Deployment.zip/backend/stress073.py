import sys,time,json
from pathlib import Path
import numpy as np
from atlas073 import run_trial,results
rows=[];t=time.monotonic()
for scenario in ('homogeneous','two_segments','cyclic','skips'):
 for budget in (90,180):
  for rep in range(80):
   seed=244311+100000*('homogeneous','two_segments','cyclic','skips').index(scenario)+10000*(budget==180)+rep
   for policy in ('balanced','variance','guarded','uniform'):
    rows.append(run_trial(seed,scenario,budget,10,policy))
summary,paired=results(rows)
p=Path('/mnt/data/atlas073_stress');p.mkdir(exist_ok=True)
(p/'summary.json').write_text(json.dumps({'trials':len(rows),'seconds':time.monotonic()-t,'summary':summary,'paired':paired},indent=2))
for x in paired:
 if x['policy']=='variance':print(x)
print('seconds',time.monotonic()-t)
