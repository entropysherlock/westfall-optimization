"""Offline anonymous CSV audit for a survey export.
Expected CSV: a,b,winner,respondent_id (optional), with winner blank for skip.
"""
import argparse,csv,json
from pathlib import Path
from engine import diagnose,next_pair

def load_csv(path):
    with open(path,encoding='utf-8-sig',newline='') as f:
        rdr=csv.DictReader(f)
        required={'a','b','winner'}
        if not required.issubset(set(rdr.fieldnames or [])):
            raise ValueError('CSV must include a,b,winner columns (optional respondent_id)')
        items=set();votes=[]
        for k,row in enumerate(rdr,2):
            a=(row['a'] or '').strip();b=(row['b'] or '').strip()
            if not a or not b:raise ValueError(f'CSV row {k} is missing a or b')
            v={'a':a,'b':b,'winner':(row['winner'] or '').strip() or None}
            if 'respondent_id' in row and row['respondent_id'] and row['respondent_id'].strip():
                v['respondent_id']=row['respondent_id'].strip()
            votes.append(v);items.update((a,b))
    return {'items':sorted(items),'votes':votes}

def main():
    p=argparse.ArgumentParser(description='Audit anonymous pairwise survey votes')
    p.add_argument('csv',help='CSV columns a,b,winner,respondent_id(optional)')
    p.add_argument('--out',default='audit_report.json')
    p.add_argument('--next-pair',action='store_true')
    a=p.parse_args()
    data=load_csv(a.csv)
    report={'audit':diagnose(data)}
    if a.next_pair: report['proposed_next_pair']=next_pair(data)
    Path(a.out).write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
    print('Wrote',a.out,'—',report['audit']['summary'])

if __name__=='__main__': main()
