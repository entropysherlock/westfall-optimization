"""Local reference HTTP adapter. Production deployment requires auth, TLS and rate limits."""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pathlib import Path
import os
from pydantic import BaseModel
from engine import next_pair, diagnose
from confidence import confidence

app=FastAPI(title='AdaptivePair Reference API',version='0.2.0',description='Stateless API for survey matchup selection and diagnostic scoring. Not an OpinionX integration.')
# Restrict browser API access to approved origins. An origin is NOT authentication.
# Public production endpoints additionally need auth, TLS, per-client quotas and monitoring.
allowed_origins=[x.strip() for x in os.getenv('ADAPTIVEPAIR_ALLOWED_ORIGINS','http://localhost:8000,http://127.0.0.1:8000,https://entropysherlock.github.io').split(',') if x.strip()]
app.add_middleware(CORSMiddleware,allow_origins=allowed_origins,allow_credentials=False,allow_methods=['GET','POST'],allow_headers=['Content-Type'])
SITE=Path(__file__).parent/'web'
@app.get('/app',include_in_schema=False)
@app.get('/app/',include_in_schema=False)
def web_app():
    return FileResponse(SITE/'index.html',media_type='text/html')
@app.get('/engine-ui.js',include_in_schema=False)
def web_script():
    return FileResponse(SITE/'engine-ui.js',media_type='text/javascript')

class Payload(BaseModel):
    items:list[str]
    votes:list[dict]=[]
    respondent_id:str|None=None
    policy:str='balanced_adaptive'
    seed:int=0
    exclude_items:list[str]=[]

class DiagnosticPayload(BaseModel):
    items:list[str]
    votes:list[dict]=[]

@app.get('/health')
def health(): return {'status':'ok','version':'0.2.0'}

@app.post('/v1/next-pair')
def select(request:Payload):
    try:return next_pair(request.model_dump())
    except ValueError as e:raise HTTPException(status_code=422,detail=str(e)) from e

@app.post('/v1/diagnostics')
def diagnostics(request:DiagnosticPayload):
    try:return diagnose(request.model_dump())
    except ValueError as e:raise HTTPException(status_code=422,detail=str(e)) from e


@app.get('/console',include_in_schema=False)
def console():
    return FileResponse(Path(__file__).parent/'console.html', media_type='text/html')

from selector073 import next_pair_073

@app.post('/v1/experimental/next-pair-073')
def select_experimental(request:Payload):
    p=request.model_dump()
    if p['policy']=='balanced_adaptive':p['policy']='variance'
    try:return next_pair_073(p)
    except ValueError as e:raise HTTPException(status_code=422,detail=str(e)) from e


class ConfidencePayload(BaseModel):
    items:list[str]
    votes:list[dict]=[]
    contrasts:list[dict]=[]
    replicates:int=200
    seed:int=0

class DecisionPayload(ConfidencePayload):
    respondent_id:str|None=None
    policy:str='variance'
    exclude_items:list[str]=[]

@app.post('/v1/confidence')
def confidence_report(request:ConfidencePayload):
    try:return confidence(request.model_dump())
    except ValueError as e:raise HTTPException(status_code=422,detail=str(e)) from e

@app.post('/v1/decision-support')
def decision_support(request:DecisionPayload):
    """Matchup suggestion plus a separate, explicitly exploratory score-gap audit."""
    p=request.model_dump()
    try:
        selection=next_pair_073(p)
        conf=confidence(p)
        return {'status':'ok','next_matchup':selection,'confidence_audit':conf}
    except ValueError as e:raise HTTPException(status_code=422,detail=str(e)) from e
