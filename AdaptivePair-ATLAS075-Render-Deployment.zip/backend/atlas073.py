"""ATLAS-073: reproducible score-gap experiment using independent Beta pair estimates.

Does NOT replace the v0.1 engine. Predefined synthetic outcomes shared by pair and
encounter index across policies. Uses constant-time posterior updates.
"""
from __future__ import annotations
import argparse,csv,json,math,time
from pathlib import Path
import numpy as np
from benchmark_072 import truth_matrix

SCENARIOS=('homogeneous','two_segments','cyclic','skips')
POLICIES=('balanced','variance','guarded','uniform')

def choose(policy, counts, yes, no, pairs, rng):
    seen=yes+no
    # Beta(1,1) posterior; analytic expected posterior variance reduction.
    alpha=yes+1; beta=no+1
    v=alpha*beta/((alpha+beta)**2*(alpha+beta+1))
    reduce=v/(alpha+beta+1)
    # Tie-breaking random, independent from outcomes, with no private identifying data.
    jitter=rng.random(len(pairs))*1e-12
    if policy=='balanced':return int(np.argmax(-counts+jitter))
    if policy=='uniform':return int(rng.integers(len(pairs)))
    if policy=='variance':return int(np.argmax(reduce+jitter))
    if policy=='guarded':
        # Exposure imbalance <= 1. Allows adaptation ONLY among minimally exposed pairs.
        lower=counts.min(); score=np.where(counts==lower,reduce,-1)
        return int(np.argmax(score+jitter))
    raise ValueError(policy)

def posterior_scores(yes,no,n,pairs):
    p=(yes+1)/(yes+no+2)
    s=np.zeros(n)
    for idx,(a,b) in enumerate(pairs):
        s[a]+=p[idx];s[b]+=1-p[idx]
    return s/(n-1)

def raw_scores(yes,no,n,pairs):
    wins=np.zeros(n); seen=np.zeros(n)
    for idx,(a,b) in enumerate(pairs):
        wins[a]+=yes[idx];wins[b]+=no[idx]
        seen[a]+=yes[idx]+no[idx];seen[b]+=yes[idx]+no[idx]
    return np.divide(wins,seen,out=np.full(n,np.nan),where=seen>0)

def gap_rmse(scores,truth):
    ok=np.isfinite(scores)
    if ok.sum()<2:return np.nan
    d=(scores-truth)[ok]
    return float(np.sqrt((len(d)*np.sum(d*d)-np.sum(d)**2)/(len(d)*(len(d)-1)/2)))

def run_trial(seed,scenario,budget,n,policy):
    rng=np.random.default_rng(seed)
    truth=truth_matrix(rng,scenario,n)
    pairs=np.array([(a,b) for a in range(n) for b in range(a+1,n)],dtype=int)
    npairs=len(pairs)
    # Hold fixed synthetic respondent noise for each pair and encounter number.
    outcome=rng.random((npairs,budget+1))
    skip=rng.random((npairs,budget+1))
    policy_rng=np.random.default_rng(seed^0x9E3779B9)
    counts=np.zeros(npairs,dtype=int); yes=np.zeros(npairs,dtype=int); no=np.zeros(npairs,dtype=int)
    for step in range(budget):
        i=choose(policy,counts,yes,no,pairs,policy_rng)
        a,b=pairs[i];t=counts[i];counts[i]+=1
        if scenario=='skips' and skip[i,t]<.17:continue
        if outcome[i,t]<truth[a,b]:yes[i]+=1
        else:no[i]+=1
    target=(truth.sum(axis=1)-.5)/(n-1)
    model=posterior_scores(yes,no,n,pairs)
    raw=raw_scores(yes,no,n,pairs)
    return {'seed':seed,'scenario':scenario,'budget':budget,'policy':policy,
        'model_gap_rmse':gap_rmse(model,target),'raw_gap_rmse':gap_rmse(raw,target),
        'coverage':float(np.mean(counts>0)),'exposure_spread':int(counts.max()-counts.min()),
        'answered':int(np.sum(yes+no))}

def benchmark(reps=200,n=6,budgets=(12,30,60),seed=73026):
    rows=[]
    for si,scenario in enumerate(SCENARIOS):
        for bi,budget in enumerate(budgets):
            for rep in range(reps):
                sd=seed+si*1000000+bi*100000+rep
                for policy in POLICIES:rows.append(run_trial(sd,scenario,budget,n,policy))
    return rows

def results(rows):
    summary=[]; paired=[]
    groups={}
    for r in rows:groups.setdefault((r['scenario'],r['budget'],r['policy']),[]).append(r)
    for (scenario,budget,policy),vals in sorted(groups.items()):
        out={'scenario':scenario,'budget':budget,'policy':policy,'n':len(vals)}
        for k in ('model_gap_rmse','raw_gap_rmse','coverage','exposure_spread','answered'):
            x=np.array([v[k] for v in vals]);x=x[np.isfinite(x)]
            out[k]=float(np.mean(x)) if len(x) else None
        summary.append(out)
    for (scenario,budget,policy),vals in sorted(groups.items()):
        if policy=='balanced':continue
        base={v['seed']:v for v in groups[(scenario,budget,'balanced')]}
        out={'scenario':scenario,'budget':budget,'policy':policy,'vs':'balanced'}
        for k in ('model_gap_rmse','raw_gap_rmse'):
            d=np.array([v[k]-base[v['seed']][k] for v in vals]);d=d[np.isfinite(d)]
            m=float(np.mean(d));se=float(np.std(d,ddof=1)/np.sqrt(len(d)))
            out[k+'_diff']=m
            out[k+'_95ci']=[m-1.96*se,m+1.96*se]
        paired.append(out)
    return summary,paired

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--reps',type=int,default=200);ap.add_argument('--seed',type=int,default=73026);ap.add_argument('--outdir',default='atlas073_results');a=ap.parse_args()
    t=time.monotonic();rows=benchmark(a.reps,seed=a.seed);summary,paired=results(rows)
    p=Path(a.outdir);p.mkdir(parents=True,exist_ok=True)
    with (p/'trials.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    report={'configuration':{'reps':a.reps,'seed':a.seed,'items':6,'budgets':[12,30,60],'scenarios':SCENARIOS,'policies':POLICIES,'trials':len(rows),'runtime_seconds':round(time.monotonic()-t,2)},'summary':summary,'paired_differences':paired}
    (p/'summary.json').write_text(json.dumps(report,indent=2))
    print('TRIALS',len(rows),'SECONDS',round(time.monotonic()-t,2),flush=True)
    for x in paired:
        if x['policy'] in ('variance','guarded') and x['budget'] in (12,30):print(x,flush=True)
if __name__=='__main__':main()
