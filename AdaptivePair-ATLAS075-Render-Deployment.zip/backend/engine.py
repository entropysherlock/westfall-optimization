"""AdaptivePair reference engine, v0.1. Stateless pair selection and diagnostics.

Research-grade reference implementation; it does not claim that adapted matchups
preserve the meaning of unadjusted win rate across unequal respondent samples.
"""
from __future__ import annotations
from collections import Counter
import hashlib
import math
from typing import Any
import numpy as np

MAX_ITEMS=250
MAX_VOTES=100_000

def _check_id(v: Any, field: str) -> str:
    if not isinstance(v, str) or not 1 <= len(v) <= 128 or v != v.strip():
        raise ValueError(f'{field} must be a nonempty, trimmed string of <=128 chars')
    return v

def parse(payload: dict):
    if not isinstance(payload, dict):
        raise ValueError('Body must be a JSON object')
    ids = payload.get('items')
    if not isinstance(ids, list) or not 2 <= len(ids) <= MAX_ITEMS:
        raise ValueError(f'items must contain 2–{MAX_ITEMS} unique IDs')
    ids=[_check_id(x,'item ID') for x in ids]
    if len(set(ids))!=len(ids): raise ValueError('item IDs must be unique')
    votes=payload.get('votes', [])
    if not isinstance(votes,list) or len(votes)>MAX_VOTES:
        raise ValueError(f'votes must be an array with at most {MAX_VOTES} records')
    ix={x:i for i,x in enumerate(ids)}
    n=len(ids)
    counts=np.zeros((n,n),dtype=np.int64)
    wins=np.zeros((n,n),dtype=np.int64)
    skips=np.zeros((n,n),dtype=np.int64)
    seen_by_respondent=set()
    for k,v in enumerate(votes):
        if not isinstance(v,dict): raise ValueError(f'votes[{k}] must be an object')
        a,b=v.get('a'),v.get('b')
        if a not in ix or b not in ix or a==b:
            raise ValueError(f'votes[{k}] has invalid pair')
        result=v.get('winner')
        if result is not None and result not in (a,b):
            raise ValueError(f'votes[{k}].winner must be a, b, or null for skip')
        ia,ib=ix[a],ix[b]
        if ia>ib: ia,ib=ib,ia
        counts[ia,ib]+=1; counts[ib,ia]+=1
        if result is None: skips[ia,ib]+=1;skips[ib,ia]+=1
        else: wins[ix[result], ix[b if result==a else a]]+=1
        rid=v.get('respondent_id')
        if rid is not None:
            _check_id(rid,'respondent_id')
            key=(rid,ia,ib)
            if key in seen_by_respondent:
                raise ValueError(f'votes[{k}] repeats a pair for the same respondent')
            seen_by_respondent.add(key)
    return ids,counts,wins,skips,seen_by_respondent

def _fit(wins, counts, skips, ridge=1.):
    # Ridge-regularized Bradley-Terry for auxiliary diagnostics only.
    # Stable at all wins/losses and disconnected comparison graphs.
    n=len(wins)
    effective=counts-skips
    theta=np.zeros(n)
    H=np.eye(n)
    for _ in range(60):
        d=np.clip(theta[:,None]-theta[None,:],-30,30)
        p=1/(1+np.exp(-d))
        w=effective*p*(1-p)
        gradient=(wins-effective*p).sum(axis=1)-ridge*theta
        H=-w;H=H.copy();np.fill_diagonal(H,w.sum(axis=1)+ridge)
        change=np.linalg.solve(H,gradient)
        # Deterministic damped Newton when sparse/unbalanced input
        change=np.clip(change,-2,2)
        theta+=change
        theta-=theta.mean()
        if np.max(np.abs(change))<1e-8: break
    d=np.clip(theta[:,None]-theta[None,:],-30,30)
    p=1/(1+np.exp(-d))
    w=effective*p*(1-p)
    H=-w;H=H.copy();np.fill_diagonal(H,w.sum(axis=1)+ridge)
    cov=np.linalg.inv(H)
    return theta,p,cov

def _pair_list(n):
    return [(a,b) for a in range(n) for b in range(a+1,n)]

def next_pair(payload:dict) -> dict:
    ids,counts,wins,skips,seen=parse(payload)
    n=len(ids)
    policy=payload.get('policy','balanced_adaptive')
    if policy not in ('balanced_adaptive','balanced','information','random'):
        raise ValueError('policy must be balanced_adaptive, balanced, information, or random')
    rid=payload.get('respondent_id')
    if rid is not None: _check_id(rid,'respondent_id')
    excluded=payload.get('exclude_items',[])
    if not isinstance(excluded,list) or any(x not in ids for x in excluded):
        raise ValueError('exclude_items must be an array of recognized item IDs')
    excluded=set(excluded)
    # Seed is a deterministic tie-breaker, not a security token.
    seed=payload.get('seed',0)
    if isinstance(seed,bool) or not isinstance(seed,int) or abs(seed)>2**31-1:
        raise ValueError('seed must be a 32-bit signed integer')
    pairs=[]
    for a,b in _pair_list(n):
        if ids[a] in excluded or ids[b] in excluded: continue
        if rid is not None and (rid,a,b) in seen: continue
        pairs.append((a,b))
    if not pairs:
        return {'status':'exhausted','pair':None,'reason':'No eligible pairs remain for this respondent and item exclusions', 'eligible_pairs':0}
    theta,p,cov=_fit(wins,counts,skips)
    min_count=min(int(counts[a,b]) for a,b in pairs)
    max_count=max(int(counts[a,b]) for a,b in pairs)
    if policy in ('balanced','balanced_adaptive'):
        candidates=[(a,b) for a,b in pairs if counts[a,b]==min_count]
    else: candidates=pairs
    def tie(a,b):
        msg=f'{seed}|{ids[a]}|{ids[b]}'.encode()
        return int.from_bytes(hashlib.sha256(msg).digest()[:8],'big')/2**64
    def info(a,b):
        var=max(0.,float(cov[a,a]+cov[b,b]-2*cov[a,b]))
        return 0.5*math.log1p(var*float(p[a,b])*(1-p[a,b]))
    if policy in ('balanced_adaptive','information'):
        best=max(candidates,key=lambda ab:(info(*ab)/(1+0.1*int(counts[ab[0],ab[1]])) if policy=='information' else info(*ab),tie(*ab)))
    else:
        best=max(candidates,key=lambda ab:tie(*ab))
    a,b=best
    return {'status':'ok','pair':{'a':ids[a],'b':ids[b]},'selection':{
        'policy':policy,'reason':('Lowest-exposure eligible pair, information-based tie break' if policy=='balanced_adaptive' else 'Lowest-exposure eligible pair' if policy=='balanced' else 'Information-gain heuristic' if policy=='information' else 'Deterministic seeded selection'),
        'pair_comparisons':int(counts[a,b]),'pair_effective_votes':int(counts[a,b]-skips[a,b]),
        'estimated_information_gain':round(info(a,b),7),
        'eligible_pairs':len(pairs),'eligible_min_exposure':min_count,'eligible_max_exposure':max_count,
        'compatibility_note':'Pair selection does not change OpinionX-style observed win-rate formula. Balanced policy limits exposure imbalance but does not establish unbiased importance gaps, particularly under dropout, skips, or heterogeneous respondents.'}}

def diagnose(payload:dict) -> dict:
    ids,counts,wins,skips,_=parse(payload)
    n=len(ids)
    theta,p,cov=_fit(wins,counts,skips)
    pairs=_pair_list(n)
    effective=counts-skips
    pair_exposures=[int(counts[a,b]) for a,b in pairs]
    connected={0}; front=[0]
    while front:
        a=front.pop()
        for b in range(n):
            if b not in connected and effective[a,b]>0:
                connected.add(b);front.append(b)
    total=int(sum(pair_exposures)); valid=int(sum(int(effective[a,b]) for a,b in pairs)); total_skips=total-valid
    coverage=sum(c>0 for c in pair_exposures)/len(pair_exposures)
    # Model-standardized scores average over *all other* options, not just actually selected opponents.
    standardized=(p.sum(axis=1)-0.5)/(n-1)*100
    rows=[]
    for i, item in enumerate(ids):
        obs=int(effective[i].sum()); w=int(wins[i].sum())
        rows.append({'item':item,'wins':w,'losses':obs-w,'skips':int(skips[i].sum()),
                     'comparisons':obs,'raw_win_rate':round(100*w/obs,3) if obs else None,
                     'model_standardized_score':round(float(standardized[i]),3),
                     'model_latent_ability':round(float(theta[i]),5)})
    rows.sort(key=lambda x:(-x['model_standardized_score'],x['item']))
    gap=None
    if n>=2:
        gap={'first':rows[0]['item'],'second':rows[1]['item'],
             'model_score_gap_points':round(rows[0]['model_standardized_score']-rows[1]['model_standardized_score'],3),
             'description':'Exploratory model-standardized gap, not an identified psychological importance difference.'}
    warning=[]
    if len(connected)<n:warning.append('Comparison graph is disconnected; model estimates depend heavily on regularization.')
    if coverage<1:warning.append('Some possible matchups have never been shown.')
    if max(pair_exposures)-min(pair_exposures)>1:warning.append('Pair exposure is uneven: raw win-rate gaps can be affected by opponents faced.')
    if total_skips: warning.append('Skips are excluded from observed win-rate denominators; skipped questions still count toward matchup exposure.')
    warning.append('Bradley–Terry model assumptions may fail with distinct respondent segments, preference cycles or adaptive missingness.')
    return {'status':'ok','summary':{'items':n,'total_comparisons':total,'answered_comparisons':valid,'skipped_comparisons':total_skips,
                'pair_coverage_fraction':round(coverage,4),'min_pair_exposure':min(pair_exposures),'max_pair_exposure':max(pair_exposures),
                'connected_comparison_graph':len(connected)==n},'scores':rows,'top_model_gap':gap,'warnings':warning,
            'methodology':{'observed_score':'100*wins/(wins+losses); skips excluded',
              'standardized_score':'Ridge-regularized BT probabilities averaged uniformly over other items; diagnostic only',
              'confidence':'No claim of calibrated uncertainty or causal effect; use randomized validation before deployment'}}
