"""ATLAS-072: randomized synthetic validation of matchup selection and score gaps.

Uses the shipping v0.1 next_pair/diagnose implementations unchanged.
Synthetic truth is fixed by replicate, and outcomes are predetermined for each
pair and encounter number, providing common random numbers across policies.
No real customer data is included. Run: python benchmark_072.py --reps 50.
"""
from __future__ import annotations
import argparse, csv, json, math
from pathlib import Path
from collections import defaultdict
import numpy as np
from engine import next_pair, diagnose

POLICIES=('random','balanced','balanced_adaptive','information')
SCENARIOS=('homogeneous','two_segments','cyclic','skips')

def sigmoid(x):
    return 1/(1+math.exp(-max(-25,min(25,float(x)))))

def truth_matrix(rng,scenario,n):
    t=rng.normal(0,1,n)
    s=rng.normal(0,1,n)
    p=np.full((n,n),.5)
    for a in range(n):
        for b in range(a+1,n):
            if scenario=='two_segments':
                q=.5*sigmoid(t[a]-t[b])+.5*sigmoid(s[a]-s[b])
            elif scenario=='cyclic':
                # Global preferences + nontransitive rock-paper-scissors structure.
                cyc=(1 if (a-b)%3==1 else -1 if (b-a)%3==1 else 0)
                q=sigmoid(.25*(t[a]-t[b])+1.7*cyc)
            else:q=sigmoid(t[a]-t[b])
            p[a,b]=q;p[b,a]=1-q
    return p

def trial(seed,scenario,n,budget,policy):
    survey_rng=np.random.default_rng(seed)
    p=truth_matrix(survey_rng,scenario,n)
    ids=[f'o{i}' for i in range(n)]
    # Predefine outcomes for each unordered pair and exposure index, independent
    # of policy. This avoids comparing policies on unrelated response noise.
    outcomes=survey_rng.random((n,n,budget+1))
    skips=survey_rng.random((n,n,budget+1))
    counts=np.zeros((n,n),dtype=int)
    votes=[]
    for step in range(budget):
        result=next_pair({'items':ids,'votes':votes,'policy':policy,'seed':int((seed*1009+step*9176)%(2**31-1))})
        if result['status']!='ok':raise RuntimeError('Unexpected exhausted selection')
        a=int(result['pair']['a'][1:]); b=int(result['pair']['b'][1:]);
        k=counts[a,b];counts[a,b]+=1
        winner=None if scenario=='skips' and skips[a,b,k]<.17 else ids[a] if outcomes[a,b,k]<p[a,b] else ids[b]
        votes.append({'a':ids[a],'b':ids[b],'winner':winner})
    report=diagnose({'items':ids,'votes':votes})
    actual=(p.sum(axis=1)-.5)/(n-1)
    estimates={int(row['item'][1:]):row for row in report['scores']}
    modeled=np.array([estimates[i]['model_standardized_score']/100 for i in range(n)])
    raw=np.array([np.nan if estimates[i]['raw_win_rate'] is None else estimates[i]['raw_win_rate']/100 for i in range(n)])
    def pair_gap_rmse(v):
        mask=np.isfinite(v)
        if mask.sum()<2:return float('nan')
        ix=np.where(mask)[0]
        d=np.array([(v[a]-v[b])-(actual[a]-actual[b]) for a in ix for b in ix if a<b])
        return float(np.sqrt(np.mean(d*d)))
    return {
       'seed':seed,'scenario':scenario,'items':n,'votes':budget,'policy':policy,
       'model_score_rmse':float(np.sqrt(np.mean((modeled-actual)**2))),
       'model_gap_rmse':pair_gap_rmse(modeled),
       'raw_score_rmse':float(np.sqrt(np.nanmean((raw-actual)**2))),
       'raw_gap_rmse':pair_gap_rmse(raw),
       'coverage':report['summary']['pair_coverage_fraction'],
       'exposure_range':report['summary']['max_pair_exposure']-report['summary']['min_pair_exposure'],
       'answered':report['summary']['answered_comparisons']
    }

def run(reps=100,n=6,budgets=(12,30),seed=72026):
    rows=[]
    for scenario in SCENARIOS:
        for budget in budgets:
            for rep in range(reps):
                survey_seed=seed+100000*SCENARIOS.index(scenario)+1000*budgets.index(budget)+rep
                for policy in POLICIES:
                    rows.append(trial(survey_seed,scenario,n,budget,policy))
    return rows

def summarize(rows):
    groups=defaultdict(list)
    for r in rows:groups[(r['scenario'],r['votes'],r['policy'])].append(r)
    out=[]
    for (scenario,budget,policy),rs in groups.items():
        d={'scenario':scenario,'votes':budget,'policy':policy,'surveys':len(rs)}
        for key in ('model_score_rmse','model_gap_rmse','raw_score_rmse','raw_gap_rmse','coverage','exposure_range','answered'):
            v=np.array([r[key] for r in rs]);v=v[np.isfinite(v)]
            d[key]=round(float(np.mean(v)),6) if len(v) else None
            d[key+'_se']=round(float(np.std(v,ddof=1)/np.sqrt(len(v))),6) if len(v)>1 else None
        out.append(d)
    return out

def differences(rows):
    # Paired standard-error confidence intervals for relative performance per
    # fixed seed/truth. Normal approximation; not an assertion of significance.
    by={(r['scenario'],r['votes'],r['seed'],r['policy']):r for r in rows}
    out=[]
    settings=sorted(set((r['scenario'],r['votes']) for r in rows))
    for scenario,budget in settings:
        seeds=sorted(set(r['seed'] for r in rows if r['scenario']==scenario and r['votes']==budget))
        for policy in ('balanced_adaptive','information'):
            d={'scenario':scenario,'votes':budget,'policy':policy,'baseline':'balanced'}
            for metric in ('model_gap_rmse','raw_gap_rmse'):
                z=np.array([by[(scenario,budget,s,policy)][metric]-by[(scenario,budget,s,'balanced')][metric] for s in seeds])
                z=z[np.isfinite(z)];mean=float(np.mean(z));se=float(np.std(z,ddof=1)/math.sqrt(len(z)))
                d[metric+'_difference']=round(mean,6)
                d[metric+'_95ci']=[round(mean-1.96*se,6),round(mean+1.96*se,6)]
            out.append(d)
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--reps',type=int,default=100)
    ap.add_argument('--items',type=int,default=6)
    ap.add_argument('--seed',type=int,default=72026)
    ap.add_argument('--budgets',nargs='+',type=int,default=[12,30])
    ap.add_argument('--outdir',default='atlas072_results')
    args=ap.parse_args()
    if args.reps<2 or not 3<=args.items<=15 or any(x<1 for x in args.budgets):ap.error('Invalid benchmark settings')
    rows=run(args.reps,args.items,args.budgets,args.seed)
    destination=Path(args.outdir);destination.mkdir(parents=True,exist_ok=True)
    with (destination/'trials.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    result={'configuration':{'replicates_per_scenario_budget_policy':args.reps,'items':args.items,'vote_budgets':args.budgets,'seed':args.seed,'surveys':len(rows),'comparisons':sum(x['votes'] for x in rows),'scenarios':list(SCENARIOS),'policies':list(POLICIES)},'summary':summarize(rows),'paired_differences':differences(rows),'limitations':['All responses synthetic; no OpinionX customer data','Model-standardized score is a diagnostic and does not establish psychological importance','The v0.1 selector refits a dense statistical model for each vote, which is not a production latency benchmark','Normal-approximation 95% intervals for paired differences; multiple comparisons not adjusted','The random policy in v0.1 is deterministic seeded tie selection with no exposure restrictions; its behavior differs from truly uniform independent random sampling','No inference that a particular comparison budget is sufficient for real customers']}
    (destination/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
    for x in result['paired_differences']:print(x)
    print('Saved',destination,'surveys',len(rows))

if __name__=='__main__':main()
