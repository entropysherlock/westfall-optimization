/* AdaptivePair web client — ATLAS-075. Always uses real API results; never invents confidence intervals. */
(()=>{'use strict';
const $=id=>document.getElementById(id);
const items=['Speed','Reliability','Ease of use','Support'];
let votes=[], current=null, connected=false, busy=false, revision=0, baseUrl='', blocked=[], respondentNumber=1, policy='guarded';
const nextRespondent=()=>`demo-respondent-${respondentNumber}`;
const safeBase=v=>{const url=new URL(v,location.href);if(!['http:','https:'].includes(url.protocol)||url.username||url.password||url.search||url.hash||url.pathname.replace(/\/$/,'')!=='')throw Error('Enter an API origin only (for example http://127.0.0.1:8000).');if(url.protocol==='http:'&&!['localhost','127.0.0.1','[::1]'].includes(url.hostname))throw Error('Remote API endpoints must use HTTPS.');return url.origin;};
function message(text,isError=false){$('connection-note').textContent=text;$('connection-note').style.color=isError?'#b13c48':'#566b85';}
function status(text){$('reason').textContent=text;}
function setConnected(v){connected=v;$('connection-state').textContent=v?'Connected to ATLAS-075':'API disconnected';$('connection-state').style.background=v?'#ddf7ef':'#fff0f0';$('connection-state').style.color=v?'#117452':'#a33b4d';$('connect').textContent=v?'Reconnect':'Connect API';$('a').disabled=!v;$('b').disabled=!v;$('skip').disabled=!v;$('sample').disabled=!v;$('undo').disabled=!v;$('reset').disabled=!v;$('policy').disabled=!v;$('respondent').disabled=!v;}
async function getJSON(path, payload, signal){const resp=await fetch(baseUrl+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal});let data;try{data=await resp.json()}catch{throw Error(`API returned unreadable response (${resp.status}).`)}if(!resp.ok)throw Error(typeof data.detail==='string'?data.detail:`API error ${resp.status}`);return data;}
function payload(){return{items,votes,respondent_id:nextRespondent(),policy,seed:17,exclude_items:blocked,replicates:100,contrasts:[{a:items[0],b:items[1]}]};}
function showScores(audit){const rows=[...(audit.scores||[])].sort((a,b)=>(b.observed_win_rate??-1)-(a.observed_win_rate??-1));$('results').replaceChildren();for(const x of rows){const row=document.createElement('div');row.className='score-row';let n=document.createElement('span');n.className='name';n.textContent=x.item;let v=document.createElement('span');v.className='value';v.textContent=x.observed_win_rate==null?'—':`${x.observed_win_rate.toFixed(1)}%`;let t=document.createElement('div');t.className='score-track';let bar=document.createElement('span');bar.style.width=`${x.observed_win_rate??0}%`;t.append(bar);row.append(n,v,t);$('results').append(row)}
const eligible=rows.filter(x=>x.observed_win_rate!=null);$('gap-label').textContent='Observed gap · 95% respondent bootstrap interval';
if(eligible.length<2){$('gap').textContent='Not enough data';$('interpret').textContent='No meaningful score gap is available yet.';return}
// Top pair is selected from observed results. Explicitly request it from ATLAS-075,
// rather than silently treating an unrelated fixed-contrast interval as the top pair.
const a=eligible[0],b=eligible[1];$('gap-label').textContent=`${a.item} vs ${b.item} · observed score gap`;
$('gap').textContent=`${(a.observed_win_rate-b.observed_win_rate).toFixed(1)} points`;
$('interpret').textContent=audit.summary.intervals_available?'Calculating respondent-aware interval for this contrast…':'Interval unavailable until at least ten respondent clusters and ten answered comparisons are recorded.';
return {a:a.item,b:b.item};}
async function refresh(){if(!connected)return;const stamp=++revision;busy=true;status('Calculating next matchup and confidence audit with ATLAS-075…');$('a').disabled=true;$('b').disabled=true;
try{
 const result=await getJSON('/v1/decision-support',payload());if(stamp!==revision)return;
 const selection=result.next_matchup, audit=result.confidence_audit;
 current=selection.pair;
 if(current){$('a').textContent=current.a;$('b').textContent=current.b;status(`API-selected ${current.a} vs ${current.b} · ${selection.selection.comparisons} prior presentations · ${selection.selection.policy} policy.`)}
 else {$('a').textContent='No pair';$('b').textContent='available';status('This respondent has no eligible pairs left. Start another respondent or reset the session.')}
 $('roundcount').textContent=`API session · ${votes.length} responses · ${audit.summary.respondent_clusters} respondent clusters`;
 $('methodnote').textContent=`ATLAS-075 cluster bootstrap · ${audit.summary.replicates} replicates · ${audit.summary.identified_respondents} identified respondents. ${audit.summary.intervals_available?'Intervals available':'Intervals unavailable'}.`;
 const top=showScores(audit);
 if(top&&audit.summary.intervals_available){const c=await getJSON('/v1/confidence',{items,votes,contrasts:[top],replicates:100,seed:17});if(stamp!==revision)return;const contrast=c.contrasts?.[0];if(contrast?.observed_win_rate_gap_interval){const [low,high]=contrast.observed_win_rate_gap_interval;$('gap').textContent=`${contrast.observed_win_rate_gap.toFixed(1)} pts [${low.toFixed(1)}, ${high.toFixed(1)}]`;$('interpret').textContent=low<=0&&high>=0?'Interval includes zero; the observed difference is not clearly separated under this exploratory bootstrap.':'Interval excludes zero in this exploratory bootstrap. This is NOT a calibrated statistical-significance claim for adaptive surveys.'}else{$('interpret').textContent='Interval unavailable for this contrast under the present response data.'}}
 $('warnings').textContent=(audit.warnings||[]).join(' ');
 }catch(e){if(stamp!==revision)return;current=null;$('a').textContent='Unavailable';$('b').textContent='Unavailable';status(`API request failed: ${e.message}`);$('gap').textContent='Unavailable';$('interpret').textContent='The service returned no trustworthy estimate. Please check your API connection.';message(`Connection or analysis error: ${e.message}`,true)}finally{if(stamp===revision){busy=false;$('a').disabled=!connected||!current;$('b').disabled=!connected||!current;}}
}
async function connect(){const input=$('api-url').value.trim();let target;try{target=safeBase(input||location.origin)}catch(e){message(e.message,true);return}baseUrl=target;setConnected(false);message('Checking API health…');try{const resp=await fetch(baseUrl+'/health',{method:'GET',cache:'no-store'});if(!resp.ok)throw Error(`HTTP ${resp.status}`);const data=await resp.json();if(data.status!=='ok')throw Error('Unexpected health response');setConnected(true);message(`Connected to ${baseUrl} · API v${data.version||'unknown'}. Only demo data should be submitted.`);await refresh()}catch(e){setConnected(false);message(`Could not connect to ${target}: ${e.message}. Start the backend or configure its public HTTPS URL and CORS.`,true);status('Connect to ATLAS-075 to begin. No confidence figures are simulated.')}}
function cast(win){if(busy||!current||!connected)return;const a=current.a,b=current.b;votes.push({a,b,winner:win,respondent_id:nextRespondent()});blocked=[];respondentNumber++;refresh()}
$('a').onclick=()=>cast(current.a);$('b').onclick=()=>cast(current.b);
$('skip').onclick=()=>{if(busy||!current)return;votes.push({a:current.a,b:current.b,winner:null,respondent_id:nextRespondent()});respondentNumber++;blocked=[];refresh()};
$('undo').onclick=()=>{if(busy)return;votes.pop();blocked=[];respondentNumber=Math.max(1,respondentNumber-1);refresh()};
$('reset').onclick=()=>{if(busy)return;votes=[];blocked=[];respondentNumber=1;refresh()};
$('respondent').onclick=()=>{if(busy)return;respondentNumber++;blocked=[];refresh()};
$('policy').onchange=()=>{policy=$('policy').value;refresh()};
$('sample').onclick=()=>{if(busy)return;votes=[];blocked=[];respondentNumber=1;let seed=29410;const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296};const theta=[1.05,.62,.15,-.25];const pairs=[];for(let i=0;i<items.length;i++)for(let j=i+1;j<items.length;j++)pairs.push([i,j]);for(let k=0;k<90;k++){const [i,j]=pairs[k%pairs.length],prob=1/(1+Math.exp(theta[j]-theta[i]));votes.push({a:items[i],b:items[j],winner:random()<prob?items[i]:items[j],respondent_id:`sample-${k+1}`})}respondentNumber=91;refresh()};
$('connect').onclick=connect;
$('api-url').addEventListener('keydown',e=>{if(e.key==='Enter')connect()});
// Same-origin local FastAPI UI connects automatically; the static site never sends
// survey data to a remote endpoint without a conscious Connect action.
if(location.hostname==='localhost'||location.hostname==='127.0.0.1'){$('api-url').value=location.origin;connect()}else{setConnected(false);$('api-url').value='';$('warnings').textContent='Connect an authorized ATLAS-075 API to see research calculations. Never paste confidential customer responses into a public endpoint.';}
})();
