import math
from atlas074 import trial, summarise

def test_trial_reproducible_and_bounded():
    a=trial(109,'fatigue_dropout',n=6,budgets=(12,24))
    assert a==trial(109,'fatigue_dropout',n=6,budgets=(12,24))
    assert len(a)==6
    for x in a:
        assert math.isfinite(x['model_gap_rmse'])
        assert 0<=x['coverage']<=1
        assert x['answered']+x['skipped']==x['budget']
        assert x['dropped']>=0

def test_summary_paired_and_savings():
    rows=[]
    for s in ('baseline','segments','fatigue_dropout','cyclic'):
        for k in range(3): rows.extend(trial(1200+k,s,n=6,budgets=(12,24)))
    a,b,c=summarise(rows,(12,24))
    assert len(a)==4*2*3
    assert len(b)==4*2*2
    assert isinstance(c,list)

def test_no_cross_respondent_leakage_on_small_budget():
    a=trial(19,'baseline',n=8,budgets=(8,))
    assert len(a)==3
    assert all(x['budget']==8 for x in a)
