import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from benchmark_072 import trial,run,summarize,differences,SCENARIOS,POLICIES

def test_deterministic_trial_and_metric_range():
    x=trial(42,'homogeneous',4,6,'balanced')
    assert x==trial(42,'homogeneous',4,6,'balanced')
    assert 0<=x['coverage']<=1
    assert 0<=x['model_gap_rmse']<=1

def test_all_preference_scenarios():
    for s in SCENARIOS:
        for p in POLICIES:
            x=trial(41,s,4,5,p)
            assert x['votes']==5
            assert x['answered']<=5

def test_summary_and_paired_comparison():
    x=run(reps=2,n=4,budgets=(4,),seed=42)
    assert len(x)==2*len(SCENARIOS)*len(POLICIES)
    assert len(summarize(x))==len(SCENARIOS)*len(POLICIES)
    assert len(differences(x))==len(SCENARIOS)*2
