import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pytest
from fastapi.testclient import TestClient
from engine import next_pair,diagnose
from api import app

ITEMS=['A','B','C','D']

def test_cold_start_deterministic():
    x={'items':ITEMS,'seed':72}
    assert next_pair(x)==next_pair(x)
    assert next_pair(x)['pair']['a']!=next_pair(x)['pair']['b']

def test_every_pair_covered_first():
    votes=[]
    for i in range(6):
        r=next_pair({'items':ITEMS,'votes':votes})
        assert r['status']=='ok'
        a,b=r['pair'].values()
        votes.append({'a':a,'b':b,'winner':a})
    assert diagnose({'items':ITEMS,'votes':votes})['summary']['pair_coverage_fraction']==1

def test_no_repeat_for_respondent():
    votes=[]
    for _ in range(6):
        r=next_pair({'items':ITEMS,'votes':votes,'respondent_id':'r1'})
        a,b=r['pair'].values()
        votes.append({'a':a,'b':b,'winner':a,'respondent_id':'r1'})
    assert next_pair({'items':ITEMS,'votes':votes,'respondent_id':'r1'})['status']=='exhausted'
    assert next_pair({'items':ITEMS,'votes':votes,'respondent_id':'r2'})['status']=='ok'

def test_skip_not_counted_as_loss():
    r=diagnose({'items':['A','B'],'votes':[{'a':'A','b':'B','winner':None},{'a':'A','b':'B','winner':'A'}]})
    assert r['summary']['skipped_comparisons']==1
    assert next(x for x in r['scores'] if x['item']=='A')['raw_win_rate']==100

def test_invalid_winner():
    with pytest.raises(ValueError):diagnose({'items':ITEMS,'votes':[{'a':'A','b':'B','winner':'C'}]})

def test_duplicate_respondent_pair_rejected():
    with pytest.raises(ValueError):diagnose({'items':ITEMS,'votes':[{'a':'A','b':'B','winner':'A','respondent_id':'r1'}, {'a':'B','b':'A','winner':'B','respondent_id':'r1'}]})

def test_exclusions_and_no_eligible():
    assert next_pair({'items':ITEMS,'exclude_items':['A','B','C']})['status']=='exhausted'
    x=next_pair({'items':ITEMS,'exclude_items':['A','B']})
    assert set(x['pair'].values())=={'C','D'}

def test_policy_and_validation():
    for policy in ['balanced','balanced_adaptive','random','information']:
        assert next_pair({'items':ITEMS,'policy':policy})['status']=='ok'
    with pytest.raises(ValueError):next_pair({'items':ITEMS,'policy':'magic'})

def test_api_endpoints():
    c=TestClient(app)
    assert c.get('/health').json()['status']=='ok'
    assert c.post('/v1/next-pair',json={'items':ITEMS}).status_code==200
    assert c.post('/v1/diagnostics',json={'items':ITEMS}).status_code==200
    assert c.post('/v1/next-pair',json={'items':ITEMS,'votes':[{'a':'A','b':'B','winner':'Z'}]}).status_code==422

def test_rate_gaps_clarity():
    v=[{'a':'A','b':'B','winner':'A'},{'a':'A','b':'B','winner':'A'}, {'a':'B','b':'C','winner':'C'}]
    d=diagnose({'items':['A','B','C'],'votes':v})
    by={x['item']:x for x in d['scores']}
    assert by['A']['raw_win_rate']==100
    assert by['B']['raw_win_rate']==0
    assert d['top_model_gap']['model_score_gap_points']>=0

def test_csv_audit(tmp_path):
    from audit import load_csv
    p=tmp_path/'votes.csv'
    p.write_text('a,b,winner,respondent_id\nA,B,A,r1\nB,C,,r1\n')
    d=diagnose(load_csv(p))
    assert d['summary']['skipped_comparisons']==1
    assert d['summary']['answered_comparisons']==1

def test_small_benchmark():
    from benchmark import run
    b=run(seed=3,reps=2,n=3,budget=4)
    assert len(b['trials'])==6
    assert all(0<=x['score_rmse']<=1 for x in b['trials'])
