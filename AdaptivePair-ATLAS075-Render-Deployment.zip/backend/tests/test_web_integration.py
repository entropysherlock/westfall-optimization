from fastapi.testclient import TestClient
from api import app

client=TestClient(app)

def test_backend_serves_real_interface():
    p=client.get('/app')
    assert p.status_code==200
    assert 'ATLAS-075 API URL' in p.text
    assert 'engine-ui.js' in p.text
    js=client.get('/engine-ui.js')
    assert js.status_code==200
    assert '/v1/decision-support' in js.text
    assert '/v1/confidence' in js.text

def test_cors_allows_github_site_not_arbitrary_origin():
    allowed=client.options('/v1/decision-support',headers={
        'Origin':'https://entropysherlock.github.io',
        'Access-Control-Request-Method':'POST',
        'Access-Control-Request-Headers':'content-type',
    })
    assert allowed.headers.get('access-control-allow-origin')=='https://entropysherlock.github.io'
    denied=client.options('/v1/decision-support',headers={
        'Origin':'https://unexpected-site.example',
        'Access-Control-Request-Method':'POST',
    })
    assert 'access-control-allow-origin' not in denied.headers

def test_real_combined_endpoint_with_identified_respondents():
    records=[{'a':'Speed','b':'Support','winner':'Speed' if k%4 else 'Support','respondent_id':f'participant-{k}'} for k in range(20)]
    body={'items':['Speed','Reliability','Ease of use','Support'],'votes':records,
        'respondent_id':'fresh-person','policy':'guarded','replicates':40,
        'contrasts':[{'a':'Speed','b':'Support'}]}
    r=client.post('/v1/decision-support',json=body)
    assert r.status_code==200
    data=r.json()
    assert data['next_matchup']['pair']
    assert data['confidence_audit']['summary']['respondent_clusters']==20
    assert data['confidence_audit']['contrasts'][0]['observed_win_rate_gap_interval'] is not None
