import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pytest
from confidence import confidence
from fastapi.testclient import TestClient
from api import app

def dataset():
    return {'items':['A','B','C'], 'votes':[
       {'a':'A','b':'B','winner':'A' if k%3 else 'B','respondent_id':f'r{k}'} for k in range(20)
    ]+[{'a':'B','b':'C','winner':'B' if k%2 else 'C','respondent_id':f'r{k}'} for k in range(20)],
    'contrasts':[{'a':'A','b':'B'}], 'replicates':60,'seed':41}

def test_deterministic_cluster_bootstrap():
    a=confidence(dataset()); b=confidence(dataset());assert a==b
    assert a['summary']['respondent_clusters']==20
    assert a['scores'][0]['observed_win_rate_interval'] is not None

def test_gap_interval_and_direction():
    c=confidence(dataset())['contrasts'][0]
    assert c['observed_win_rate_gap']>0
    assert c['observed_win_rate_gap_interval'][0] <= c['observed_win_rate_gap_interval'][1]
    assert c['model_standardized_gap_interval'] is not None

def test_skips_are_not_losses():
    p={'items':['A','B'],'votes':[{'a':'A','b':'B','winner':None},{'a':'A','b':'B','winner':'A'}]}
    r=confidence(p)
    assert r['scores'][0]['observed_win_rate']==100
    assert r['summary']['answered']==1
    assert not r['summary']['intervals_available']

def test_missing_respondents_warning():
    p={'items':['A','B'],'votes':[{'a':'A','b':'B','winner':'A'} for _ in range(12)],'replicates':40}
    assert any('without respondent_id' in s for s in confidence(p)['warnings'])

def test_repeated_person_preserved_as_cluster():
    r=confidence(dataset())
    assert r['summary']['respondent_clusters']==20
    assert r['summary']['responses']==40

def test_invalid_input():
    with pytest.raises(ValueError):confidence({**dataset(),'contrasts':[{'a':'A','b':'Z'}]})
    with pytest.raises(ValueError):confidence({**dataset(),'replicates':5})

def test_integrated_endpoints():
    c=TestClient(app)
    assert c.post('/v1/confidence',json=dataset()).status_code==200
    p={**dataset(),'respondent_id':'fresh','policy':'variance'}
    r=c.post('/v1/decision-support',json=p)
    assert r.status_code==200,r.text
    d=r.json()
    assert d['next_matchup']['pair']
    assert d['confidence_audit']['summary']['intervals_available']

def test_empty_survey_does_not_claim_confidence():
    r=confidence({'items':['A','B'],'votes':[]})
    assert r['scores'][0]['observed_win_rate'] is None
    assert r['scores'][0]['observed_win_rate_interval'] is None
