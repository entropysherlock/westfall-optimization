import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from selector073 import next_pair_073
from fastapi.testclient import TestClient
from api import app

def test_cold_start_covered():
    items=['A','B','C','D'];votes=[];seen=set()
    for i in range(6):
        res=next_pair_073({'items':items,'votes':votes})
        a,b=res['pair'].values();seen.add((a,b));votes.append({'a':a,'b':b,'winner':a})
    assert len(seen)==6

def test_skipped_pairs_still_expose():
    r=next_pair_073({'items':['A','B','C'],'votes':[{'a':'A','b':'B','winner':None}]})
    assert set(r['pair'].values())!={'A','B'}

def test_respondent_exclusion():
    rows=[{'a':'A','b':'B','winner':'A','respondent_id':'r'}]
    r=next_pair_073({'items':['A','B','C'],'votes':rows,'respondent_id':'r'})
    assert set(r['pair'].values())!={'A','B'}

def test_repeatability():
    p={'items':['A','B','C'],'seed':42}
    assert next_pair_073(p)==next_pair_073(p)

def test_api_073():
    r=TestClient(app).post('/v1/experimental/next-pair-073',json={'items':['A','B','C']})
    assert r.status_code==200 and r.json()['status']=='ok'

def test_no_repeats_exhausted():
    rows=[{'a':'A','b':'B','winner':'A','respondent_id':'r'}]
    assert next_pair_073({'items':['A','B'],'votes':rows,'respondent_id':'r'})['status']=='exhausted'
